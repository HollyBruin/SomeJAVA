public class stack1_c {
    private static final int MAX = 10;
    private char[] data;
    private int top;

    public stack1_c() {
        data = new char[MAX];
        top = -1; // Yığının başlangıçta boş olduğunu belirtmek için -1 kullanılır.
    }

    // Yığına eleman ekler
    public boolean push(char item) {
        if (top == MAX - 1) {
            System.out.println("Stack overflow! Yığın dolu, eleman eklenemedi.");
            return false;
        } else {
            data[++top] = item;
            return true;
        }
    }

    // Yığından eleman çıkarır
    public char pop() {
        if (isEmpty()) {
            System.out.println("Stack underflow! Yığın boş, eleman çıkarılamaz.");
            return '\0'; // Karakter olmayan bir değer döndürerek hatayı belirtiyoruz.
        } else {
            return data[top--];
        }
    }

    // Yığının boş olup olmadığını kontrol eder
    public boolean isEmpty() {
        return (top == -1);
    }

    static Stack k(char[] t){
        Stack s = new Stack();
        for( int a=0;(t)!=null; a++){
            s.push(t);
            return s;
        }

        return s;
    }
    static void y(Stack s){
        while(s.pop()!=-1) System.out.println(s.pop());
    }
    public static void main(String args[]){
        Stack s = k("Merhabalar".toCharArray());
        y(s); }

}