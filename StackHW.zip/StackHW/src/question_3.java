import java.util.LinkedList;
import java.util.Scanner;

class Elemanq3 {
    String ad;
    String soyad;
    String dogumTarihi;
    String telefonNo;

    Elemanq3(String ad, String soyad, String dogumTarihi, String telefonNo) {
        this.ad = ad;
        this.soyad = soyad;
        this.dogumTarihi = dogumTarihi;
        this.telefonNo = telefonNo;
    }
}

class KuyrukLinkedList {
    private LinkedList<Eleman> kuyruk = new LinkedList<>();

    // Kuyruğa eleman ekle
    void kuyrugaEkle(Eleman yeniEleman) {
        kuyruk.addLast(yeniEleman);
    }

    // Kuyruktan eleman çek
    Eleman kuyruktanCek() {
        if (kuyruk.isEmpty()) {
            System.out.println("Kuyruk boş.");
            return null;
        }
        return kuyruk.removeFirst();
    }

    // Kuyruktaki eleman sayısını al
    int kuyrukElemanSayisi() {
        return kuyruk.size();
    }

    // Kuyrukta isim ara
    void kuyruktaAra(String arananIsim) {
        if (kuyruk.isEmpty()) {
            System.out.println("Kuyruk boş.");
            return;
        }

        for (int i = 0; i < kuyruk.size(); i++) {
            if (kuyruk.get(i).ad.equals(arananIsim)) {
                System.out.println("Kuyrukta aranan " + arananIsim + " ismi kuyruğun " + (i + 1) + ". sırasında.");
                return;
            }
        }

        System.out.println("Kuyrukda aranan " + arananIsim + " bulunamamıştır.");
    }

    // Kuyruktaki tüm elemanları yazdır
    void kuyruktakiElemanlariYazdir() {
        if (kuyruk.isEmpty()) {
            System.out.println("Kuyruk boş.");
            return;
        }

        for (Eleman eleman : kuyruk) {
            System.out.println("Ad: " + eleman.ad + ", Soyad: " + eleman.soyad +
                    ", Doğum Tarihi: " + eleman.dogumTarihi + ", Telefon No: " + eleman.telefonNo);
        }
    }
}

public class question_3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        KuyrukLinkedList kuyruk = new KuyrukLinkedList();

        while (true) {
            System.out.println("1. Kuyruğa ekle");
            System.out.println("2. Kuyruktan çek");
            System.out.println("3. Kuyruk eleman sayısı");
            System.out.println("4. Kuyrukta ara");
            System.out.println("5. Kuyruktaki elemanları listeleyin");
            System.out.println("0. Çıkış");
            System.out.print("İstediğiniz komutu giriniz: ");

            int secim = scanner.nextInt();
            scanner.nextLine(); // Dummy satır okuma

            switch (secim) {
                case 1:
                    System.out.println("Kuyruğa eklenecek yeni adı giriniz: ");
                    String ad = scanner.nextLine();
                    System.out.println("Kuyruğa eklenecek yeni soyadı giriniz: ");
                    String soyad = scanner.nextLine();
                    System.out.println("Kuyruğa eklenecek yeni Doğum tarihini giriniz: ");
                    String dogumTarihi = scanner.nextLine();
                    System.out.println("Kuyruğa eklenecek yeni Telefon numarasını giriniz: ");
                    String telefonNo = scanner.nextLine();
                    Eleman yeniEleman = new Eleman(ad, soyad, dogumTarihi, telefonNo);
                    kuyruk.kuyrugaEkle(yeniEleman);
                    break;
                case 2:
                    Eleman cekilenEleman = kuyruk.kuyruktanCek();
                    if (cekilenEleman != null) {
                        System.out.println("Kuyruktan çekilen kişi: Ad: " + cekilenEleman.ad +
                                ", Soyad: " + cekilenEleman.soyad +
                                ", Doğum Tarihi: " + cekilenEleman.dogumTarihi +
                                ", Telefon No: " + cekilenEleman.telefonNo);
                    }
                    break;
                case 3:
                    System.out.println("Kuyrukda " + kuyruk.kuyrukElemanSayisi() + " adet eleman vardır.");
                    break;
                case 4:
                    System.out.println("Kuyrukta aranacak ismi giriniz: ");
                    String arananIsim = scanner.nextLine();
                    kuyruk.kuyruktaAra(arananIsim);
                    break;
                case 5:
                    kuyruk.kuyruktakiElemanlariYazdir();
                    break;
                case 0:
                    System.out.println("Programdan çıkılıyor...");
                    System.exit(0);
                default:
                    System.out.println("Geçersiz bir seçim yaptınız. Lütfen tekrar deneyin.");
            }
        }
    }
}
