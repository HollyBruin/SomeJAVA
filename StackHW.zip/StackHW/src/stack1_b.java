/*public class stack1_b {
        private static final int MAX = 10;
        private char[] data;
        private int top;

        public stack1_b() {
            data = new char[MAX];
            top = -1; // Yığının başlangıçta boş olduğunu belirtmek için -1 kullanılır.
        }

        // Yığına eleman ekler
        public boolean push(char item) {
            if (top == MAX - 1) {
                System.out.println("Stack overflow! Yığın dolu, eleman eklenemedi.");
                return false;
            } else {
                data[++top] = item;
                return true;
            }
        }

        // Yığından eleman çıkarır
        public char pop() {
            if (isEmpty()) {
                System.out.println("Stack underflow! Yığın boş, eleman çıkarılamaz.");
                return '\0'; // Karakter olmayan bir değer döndürerek hatayı belirtiyoruz.
            } else {
                return data[top--];
            }
        }

        // Yığının boş olup olmadığını kontrol eder
        public boolean isEmpty() {
            return (top == -1);
        }

    public static void main(String args[]){
        Stack s[]= new Stack[3];
        char t;
        for(int i=0;i<10;i++) s[0].push((char) i);
        while(s[0].isEmpty()) {
            t=s[0].pop();
            if(t%3==0) s[1].push(t);
            else s[2].push(t);
        }
        for(int i=1;i<3;i++){
            t=s[i].pop();
            System.out.println(t);
        }}
}*/
public class stack1_b {
    private static final int MAX = 10;
    private char[] data;
    private int top;

    public stack1_b() {
        data = new char[MAX];
        top = -1; // Yığının başlangıçta boş olduğunu belirtmek için -1 kullanılır.
    }

    // Yığına eleman ekler
    public boolean push(char item) {
        if (top == MAX - 1) {
            System.out.println("Stack overflow! Yığın dolu, eleman eklenemedi.");
            return false;
        } else {
            data[++top] = item;
            return true;
        }
    }

    // Yığından eleman çıkarır
    public char pop() {
        if (isEmpty()) {
            System.out.println("Stack underflow! Yığın boş, eleman çıkarılamaz.");
            return '\0'; // Karakter olmayan bir değer döndürerek hatayı belirtiyoruz.
        } else {
            return data[top--];
        }
    }

    // Yığının boş olup olmadığını kontrol eder
    public boolean isEmpty() {
        return (top == -1);
    }

    public static void main(String args[]) {
        stack1_b s[] = new stack1_b[3];
        for (int i = 0; i < 3; i++) {
            s[i] = new stack1_b(); // Her bir Stack örneğini oluştur
        }

        char t;
        for (int i = 0; i < 10; i++) {
            s[0].push((char) i);
        }

        while (!s[0].isEmpty()) {
            t = s[0].pop();
            if (t % 3 == 0) {
                s[1].push(t);
            } else {
                s[2].push(t);
            }
        }

        for (int i = 1; i < 3; i++) {
            while (!s[i].isEmpty()) {
                t = s[i].pop();
                System.out.println(t);
            }
        }
    }
}

