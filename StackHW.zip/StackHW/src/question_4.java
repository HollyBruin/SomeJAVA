import java.util.LinkedList;
import java.util.Scanner;

class Elemanq4 {
    String ad;
    String soyad;
    String dogumTarihi;
    String telefonNo;

    Elemanq4(String ad, String soyad, String dogumTarihi, String telefonNo) {
        this.ad = ad;
        this.soyad = soyad;
        this.dogumTarihi = dogumTarihi;
        this.telefonNo = telefonNo;
    }
}

class StackLinkedList {
    private LinkedList<Eleman> yigin = new LinkedList<>();

    // Yığına eleman ekle
    void yiginaEkle(Eleman yeniEleman) {
        yigin.addFirst(yeniEleman);
    }

    // Yığından eleman çek
    Eleman yigindanCek() {
        if (yigin.isEmpty()) {
            System.out.println("Yığın boş.");
            return null;
        }
        return yigin.removeFirst();
    }

    // Yığındaki eleman sayısını al
    int yiginElemanSayisi() {
        return yigin.size();
    }

    // Yığında isim ara
    void yigindaAra(String arananIsim) {
        if (yigin.isEmpty()) {
            System.out.println("Yığın boş.");
            return;
        }

        for (int i = 0; i < yigin.size(); i++) {
            if (yigin.get(i).ad.equals(arananIsim)) {
                System.out.println("Aranan isim yığının " + (i + 1) + ". sırasındadır.");
                return;
            }
        }

        System.out.println("Yığında aranan " + arananIsim + " bulunamamıştır.");
    }

    // Yığındaki tüm elemanları yazdır
    void yigindakiElemanlariYazdir() {
        if (yigin.isEmpty()) {
            System.out.println("Yığın boş.");
            return;
        }

        for (Eleman eleman : yigin) {
            System.out.println("Ad: " + eleman.ad + ", Soyad: " + eleman.soyad +
                    ", Doğum Tarihi: " + eleman.dogumTarihi + ", Telefon No: " + eleman.telefonNo);
        }
    }
}

public class question_4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StackLinkedList yigin = new StackLinkedList();

        while (true) {
            System.out.println("1. Yığına ekle");
            System.out.println("2. Yığından çek");
            System.out.println("3. Yığın eleman sayısı");
            System.out.println("4. Yığında ara");
            System.out.println("5. Yığındaki elemanları listeleyin");
            System.out.println("0. Çıkış");
            System.out.print("İstediğiniz komutu giriniz: ");

            int secim = scanner.nextInt();
            scanner.nextLine(); // Dummy satır okuma

            switch (secim) {
                case 1:
                    System.out.println("Yığına eklenecek yeni adı giriniz: ");
                    String ad = scanner.nextLine();
                    System.out.println("Yığına eklenecek yeni soyadı giriniz: ");
                    String soyad = scanner.nextLine();
                    System.out.println("Yığına eklenecek yeni Doğum tarihini giriniz: ");
                    String dogumTarihi = scanner.nextLine();
                    System.out.println("Yığına eklenecek yeni Telefon numarasını giriniz: ");
                    String telefonNo = scanner.nextLine();
                    Eleman yeniEleman = new Eleman(ad, soyad, dogumTarihi, telefonNo);
                    yigin.yiginaEkle(yeniEleman);
                    break;
                case 2:
                    Eleman cekilenEleman = yigin.yigindanCek();
                    if (cekilenEleman != null) {
                        System.out.println("Yığından çekilen kişi: Ad: " + cekilenEleman.ad +
                                ", Soyad: " + cekilenEleman.soyad +
                                ", Doğum Tarihi: " + cekilenEleman.dogumTarihi +
                                ", Telefon No: " + cekilenEleman.telefonNo);
                    }
                    break;
                case 3:
                    System.out.println("Yığında " + yigin.yiginElemanSayisi() + " adet eleman vardır.");
                    break;
                case 4:
                    System.out.println("Yığında aranacak ismi giriniz: ");
                    String arananIsim = scanner.nextLine();
                    yigin.yigindaAra(arananIsim);
                    break;
                case 5:
                    yigin.yigindakiElemanlariYazdir();
                    break;
                case 0:
                    System.out.println("Programdan çıkılıyor...");
                    System.exit(0);
                default:
                    System.out.println("Geçersiz bir seçim yaptınız. Lütfen tekrar deneyin.");
            }
        }
    }
}
