import java.util.Scanner;

class Eleman {
    String ad;
    String soyad;
    String dogumTarihi;
    String telefonNo;
    Eleman sonraki;

    Eleman(String ad, String soyad, String dogumTarihi, String telefonNo) {
        this.ad = ad;
        this.soyad = soyad;
        this.dogumTarihi = dogumTarihi;
        this.telefonNo = telefonNo;
        this.sonraki = null;
    }
}

class BagliListe {
    private Eleman bas;

    // Liste başına eleman ekle
    void listeBasinaEkle(Eleman yeniEleman) {
        yeniEleman.sonraki = bas;
        bas = yeniEleman;
    }

    // Liste sonuna eleman ekle
    void listeSonunaEkle(Eleman yeniEleman) {
        if (bas == null) {
            bas = yeniEleman;
            return;
        }

        Eleman temp = bas;
        while (temp.sonraki != null) {
            temp = temp.sonraki;
        }
        temp.sonraki = yeniEleman;
    }

    // Liste elemanlarını ekrana yazdır
    void listeYazdir() {
        if (bas == null) {
            System.out.println("Liste boş.");
            return;
        }

        Eleman temp = bas;
        while (temp != null) {
            System.out.println("Ad: " + temp.ad + ", Soyad: " + temp.soyad +
                    ", Doğum Tarihi: " + temp.dogumTarihi + ", Telefon No: " + temp.telefonNo);
            temp = temp.sonraki;
        }
    }

    // Liste eleman sayısını bul
    int elemanSayisi() {
        int count = 0;
        Eleman temp = bas;
        while (temp != null) {
            count++;
            temp = temp.sonraki;
        }
        return count;
    }

    // Belirli bir değeri içeren elemanı bul
    Eleman elemanAra(String arananDeger) {
        Eleman temp = bas;
        int sira = 1;
        while (temp != null) {
            if (temp.ad.equals(arananDeger) || temp.soyad.equals(arananDeger) ||
                    temp.dogumTarihi.equals(arananDeger) || temp.telefonNo.equals(arananDeger)) {
                System.out.println("Aranan değer listenin " + sira + ". sırasındadır.");
                return temp;
            }
            temp = temp.sonraki;
            sira++;
        }
        System.out.println("Listede değer bulunamamıştır.");
        return null;
    }

    // Liste elemanını sil
    void elemanSil(String ad) {
        if (bas == null) {
            System.out.println("Liste boş, silme işlemi tamamlanamadı.");
            return;
        }

        if (bas.ad.equals(ad)) {
            bas = bas.sonraki;
            System.out.println("Silme işlemi tamamlandı.");
            return;
        }

        Eleman onceki = bas;
        Eleman temp = bas.sonraki;

        while (temp != null && !temp.ad.equals(ad)) {
            onceki = temp;
            temp = temp.sonraki;
        }

        if (temp == null) {
            System.out.println("Listede belirtilen adı taşıyan eleman bulunamamıştır.");
            return;
        }

        onceki.sonraki = temp.sonraki;
        System.out.println("Silme işlemi tamamlandı.");
    }
}

public class question_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BagliListe liste = new BagliListe();

        while (true) {
            System.out.println("1. Listeye ekle");
            System.out.println("2. Listeden sil");
            System.out.println("3. Liste eleman sayısı");
            System.out.println("4. Listede ara");
            System.out.println("5. Liste yaz");
            System.out.println("0. Çıkış");
            System.out.print("İstediğiniz komutu giriniz: ");

            int secim = scanner.nextInt();
            scanner.nextLine(); // Dummy satır okuma

            switch (secim) {
                case 1:
                    System.out.println("Listeye eklenecek yeni adı giriniz: ");
                    String ad = scanner.nextLine();
                    System.out.println("Listeye eklenecek yeni soyadı giriniz: ");
                    String soyad = scanner.nextLine();
                    System.out.println("Listeye eklenecek yeni Doğum tarihini giriniz: ");
                    String dogumTarihi = scanner.nextLine();
                    System.out.println("Listeye eklenecek yeni Telefon numarasını giriniz: ");
                    String telefonNo = scanner.nextLine();
                    Eleman yeniEleman = new Eleman(ad, soyad, dogumTarihi, telefonNo);
                    System.out.println("Listeye eklenecek konumu seçiniz (1: Başa, 2: Sona): ");
                    int konumSecimi = scanner.nextInt();
                    if (konumSecimi == 1) {
                        liste.listeBasinaEkle(yeniEleman);
                    } else if (konumSecimi == 2) {
                        liste.listeSonunaEkle(yeniEleman);
                    }
                    break;
                case 2:
                    System.out.println("Listeden silinecek kişinin adını giriniz: ");
                    String silinecekAd = scanner.nextLine();
                    liste.elemanSil(silinecekAd);
                    break;
                case 3:
                    System.out.println("Listede " + liste.elemanSayisi() + " adet eleman vardır.");
                    break;
                case 4:
                    System.out.println("Listede aranacak int değeri giriniz: ");
                    String arananDeger = scanner.nextLine();
                    Eleman bulunanEleman = liste.elemanAra(arananDeger);
                    if (bulunanEleman != null) {
                        System.out.println("Aranan değer: Ad: " + bulunanEleman.ad +
                                ", Soyad: " + bulunanEleman.soyad +
                                ", Doğum Tarihi: " + bulunanEleman.dogumTarihi +
                                ", Telefon No: " + bulunanEleman.telefonNo);
                    }
                    break;
                case 5:
                    liste.listeYazdir();
                    break;
                case 0:
                    System.out.println("Programdan çıkılıyor...");
                    System.exit(0);
                default:
                    System.out.println("Geçersiz bir seçim yaptınız. Lütfen tekrar deneyin.");
            }
        }
    }
}
