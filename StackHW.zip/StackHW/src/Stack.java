public class Stack {
    private static final int MAX = 10;
    private char[] data;
    private int top;

    public Stack() {
        data = new char[MAX];
        top = -1; // Yığının başlangıçta boş olduğunu belirtmek için -1 kullanılır.
    }

    // Yığına eleman ekler
    public boolean push(char item) {
        if (top == MAX - 1) {
            System.out.println("Stack overflow! Yığın dolu, eleman eklenemedi.");
            return false;
        } else {
            data[++top] = item;
            return true;
        }
    }

    // Yığından eleman çıkarır
    public char pop() {
        if (isEmpty()) {
            System.out.println("Stack underflow! Yığın boş, eleman çıkarılamaz.");
            return '\0'; // Karakter olmayan bir değer döndürerek hatayı belirtiyoruz.
        } else {
            return data[top--];
        }
    }

    // Yığının boş olup olmadığını kontrol eder
    public boolean isEmpty() {
        return (top == -1);
    }

    static int f(int a){

        return a;
    }

    public void push(char[] t) {
    }

    public static class main {
        public static int main(String[] args, int a) {
            stack1_c s = new stack1_c();
            int k = 1;
            for(int i=a;i>0;i--){
                s.push((char) i);
            }
            while (s.pop()==(char) a){
                k++;
            }
            return k;


        }
        public static void main (String[] args){
            System.out.println(f(5) + f(4) + f(3) + f(2) );
        }
    }
}